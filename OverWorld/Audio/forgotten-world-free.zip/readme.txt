Thank you so much for your download.
Music composed by sutheecomposer from HookSounds.com

Your support means the world to us and we hope that you are happy with your download. If there's anything that we can do to make you even happier, please let us know!

=========================================================================================================

This sound or music is under the Attribution Creative Commons 4.0 license (http://creativecommons.org/about/licenses/)
That means YOU MUST GIVE ATTRIBUTION to HookSounds for this artwork either if you use it in your video, website or any other purpose. Please add a DO FOLLOW LINK POINTING TO http://www.hooksounds.com

For example: a text like "Music: www.hooksounds.com" or "Royalty Free Music from HookSounds" with a link to http://www.hooksounds.com is ok.

This license lets others distribute, remix, tweak, and build upon your work, even commercially, as long as they credit you for the original creation. This is the most accommodating of licenses offered, in terms of what others can do with your works licensed under Attribution.

If you want to use this sound or music file without giving attribution, you MUST purchase its license at http:/www.hooksounds.com

Make sure to visit hooksounds.com in the future for more sounds.

Hope you enjoy my music!

http://www.hooksounds.com
https://www.facebook.com/HookSounds